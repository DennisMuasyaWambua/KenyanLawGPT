# AI Use Disclosure (DSA 8401 capstone)


## Tools
- **Claude Code** (Anthropic CLI; model: Claude Sonnet 5.5, `claude-sonnet-5-5`), used interactively in this repository, Nov 2026.
- The parent product (Advocatus) was  built using Next js( frontend ), Go lang(API gateway),Python for the AI model
- Claude code was used to develop the Front end and part of the api gateway and the proto buffs
## What the AI did for the capstone
| Area | AI contribution |
|---|---|
| Audit | Read `services/ai` and reported that production retrieval is dense-only (pgvector) with no BM25, a tiny crawled corpus and no evaluation. |
| Deployment | Wrote and ran server bootstrap, nginx config, CI/CD deploy job and the first deploy of the Advocatus stack to a VPS. Not part of the graded ML work. |
| Writing | Drafted `README.md`, this file and `docs/REPORT.md` (structure, technique justification, limitations). |

## What the AI did NOT do
- It did **not** produce any real-data result. All numbers in the repo come from a 12-document synthetic fixture
  and are labelled as such. [Student: delete this line only if you later add real results you generated yourself.]
- It did not label relevance judgements. [Student: confirm you labelled the real qrels yourself with `build_qrels`;
  if an LLM helped, say exactly how and report agreement.]
- Corpus selection, query writing, interpretation of results and the final defence are the student's. [Student: confirm.]

## Verification performed
Unit/integration tests (21) pass; the Docker image builds and serves `/healthz` and `/query`; metric formulas
were checked against hand-computed nDCG/MRR cases. AI-written code was not independently audited by the student
[Student: record what you reviewed].

## Data handling
The exporter reads only the shared public legal corpus, never tenant (client) schemas. No client-confidential
data is in this repository. Document text is not sent to any external service by the capstone code.
