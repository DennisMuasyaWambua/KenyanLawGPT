# Retrieval-Augmented Precedent Search for Kenyan Case Law: Final Report
DSA 8401 Applied Machine Learning. Individual capstone.

> **Status.** Everything below that is a design decision or an argument is final. Every **empirical result** is
> marked `[RESULT]` and must be filled from `results/test_results.md` after running the pipeline on the real
> corpus with hand-labelled queries. No real-data numbers exist yet; the bundled run is a synthetic smoke test.

## 1. Problem framing
**Task.** Given a free-text legal issue, rank Kenyan court judgments by relevance (ad-hoc retrieval), returning
passages an advocate can verify. **Why it matters.** Binding precedent drives outcomes; manual search over the
~80-100k-case Kenya Law corpus is slow and misses authorities. **Success** is defined as *finding all relevant
precedents near the top*: recall@10 and nDCG@10 (primary), MRR, with uncertainty quantified.
**Why retrieval, not generation, is the thing to evaluate.** In legal use a fabricated citation is worse than a
missed one. Retrieval is measurable against ground truth; generated prose is not, and is downstream of retrieval
quality (if the right case is not retrieved, no generator can cite it).

## 2. Data
- **Source:** public Kenya Law Reports judgments, ingested into Postgres (`public_documents`) by the Advocatus
  pipeline and exported by `rag_eval.export_pg` (public schema only). Citation edges come from Neo4j `CITES`
  edges and exact-citation matching in text.
- **Real-world messiness (course requirement):** inconsistent judgment formatting, OCR damage in older scans,
  stubs, duplicated ids, dangling citation edges. Handled in `ingest` and documented in `ingest_report.json`.
  The OCR complication is additionally **simulated at controlled rates** (`--noise`) so the effect of
  cleaning can be measured, not assumed.
- **Labels:** ~100 realistic advocate queries with graded relevance (0-3), built by **pooling** the top-10 of every
  system, shuffled and blind to system, then judged by hand (`build_qrels`). Unjudged = non-relevant; pool depth
  is reported. `[RESULT: n queries, pool size, % queries with >=1 relevant]`
- **Split:** queries are split 50/50 dev/test with a seed; hyper-parameters are tuned on dev only; test is
  touched once by `evaluate`. Documents are shared across splits, which is correct for retrieval (the corpus is the
  index), but queries are not.

## 3. Method and technique justification
**Chosen model: weighted RRF fusion of BM25 and dense retrieval, optional citation-graph expansion.**

| Decision | Why | What was ruled out, and why |
|---|---|---|
| BM25 as a first-class retriever | Legal queries hinge on exact terms: statute sections, party names, "Article 47". Lexical match is a strong, cheap, interpretable baseline that learned embeddings often fail to beat in-domain. | *Dense-only* (the current production design): misses exact-term queries; shown by ablation `[RESULT]`. |
| Dense embeddings in the fusion | Captures paraphrase ("sacked without hearing" ~ "unfair termination"). Offline hashing embedder gives a reproducible floor; a learned model (`--dense st:...`) is the real comparison. | *Hashing embedder as the final dense model*: it is lexical in nature, so it is a floor, not evidence about semantics. |
| Reciprocal Rank Fusion | Needs no score calibration between BM25 and cosine scales; two parameters (k, weights); robust with small dev sets. | *Learned fusion / learning-to-rank*: needs far more labelled queries than ~50 dev queries; would overfit (we already see tuning noise, §5). |
| Citation-graph expansion | Precedent search is citation-driven: authorities cited by a strong hit are often relevant. Ablated, not assumed. | *Always-on graph boost*: kept as a tuned on/off switch because it can hurt precision `[RESULT]`. |
| Chunking + title prepended | Judgments are long; chunk size is a first-order retrieval parameter, so it is tuned (400/800/1200). | *Document-level embedding*: truncation loses the holding. |
| Extractive summary in the API | Cannot hallucinate; every sentence traces to a retrieved case. | *LLM synthesis as the served output*: not evaluated here, adds unverifiable fabrication risk; kept in the Advocatus product behind citation-grounded prompts, outside the graded model. |
| No fine-tuning | No labelled (query, case) pairs at scale; ~100 pooled queries are enough to *evaluate*, not to fine-tune without leakage. | *LoRA / embedding fine-tuning*: listed as future work once labels exist. |
| No cross-encoder reranker | Compute/latency cost and a second model to defend; first measure how much headroom the first stage leaves (recall@50 vs @10). | Future work. |
| Vector store | Reproducibility: the harness is numpy-only and runs for a reviewer with no databases. Production uses pgvector. | Pinecone (named in the proposal): a managed dependency adds nothing to the evaluation. **Deviation from proposal, deliberate.** |
| Unsupervised/clustering, classical classifiers | Not a fit: the task is ranking, not classification. | Considered and excluded. |

## 4. Evaluation protocol
Metrics: recall@10, recall@5, precision@10, hit@10, MRR@10, nDCG@10 (graded gains 2^g-1). Uncertainty: 95%
percentile bootstrap over queries; system differences use a **paired** bootstrap vs BM25 (Δ nDCG, CI, p).
Ablations: BM25-only, dense-only, default fusion, tuned fusion, graph on/off, chunk size, OCR noise
with/without cleaning. Leakage controls: dev/test query split; hyper-parameters never see test; qrels pooling is
blind to system; the tuned chunk size is shared across baselines so differences isolate retrieval.

## 5. Results `[RESULT: paste results/test_results.md and run_eval ablation tables here]`
- Main comparison table (test set) `[RESULT]`
- OCR noise: effect of cleaning `[RESULT]`
- Chunk-size sweep `[RESULT]`
- **Error analysis:** inspect `test_per_query.json`; list the 5 worst queries per system and why they failed `[RESULT]`
- **Interpretation, not just reporting:** state which differences are statistically distinguishable from zero
  given the CIs, and which are not.

**What the smoke test already teaches (synthetic data, 5 dev / 5 test queries).** Tuning raised dev nDCG@10 from
0.81 to 0.99 but the tuned model scored the same as the untuned default on test (0.889 vs 0.889). That is
textbook selection overfitting on a tiny dev set, and is why the real run needs >= 50 queries and why the report
must quote test, not dev, numbers.

## 6. Deployment
FastAPI service (`rag_service/app.py`) loads the exact serialized artifacts that were evaluated; Docker image
(non-root, healthcheck), `docker-compose.yml`; `/healthz` exposes git sha, parameters and counts for provenance.
Reproduce from the README in ~10 seconds on the sample data. Latency: `[RESULT: ms/query on the real corpus]`.

## 7. Limitations (known, not hypothetical)
1. **Labels:** a pool-based test set under-counts relevant documents that no system retrieved, which favours systems
   resembling the pool; ~100 queries give wide CIs; one annotator, no inter-annotator agreement.
2. **Distribution:** queries are written by the student, not drawn from advocates' real logs.
3. **Corpus coverage:** only what was crawled/exported; if eKLR coverage is partial, recall is relative to that corpus.
4. **Temporal:** no temporal split; later judgments citing earlier ones are in the same index. Overruled or
   superseded authority is flagged in the Advocatus product but not scored here.
5. **Dense model:** the offline default is lexical; semantic gains are only demonstrated if a learned embedder is run.
6. **Not legal advice.** Output is a research aid; every authority must be verified against the full judgment.
7. **Fairness/monitoring:** no subgroup analysis (e.g. by court level or year) or drift monitoring yet `[future work]`.

## 8. Real-world relevance
Directly useful as the retrieval layer of an advocate-facing research tool (the Advocatus product). Because the
evaluation harness is decoupled from the product, any future retriever (learned embeddings, reranker) can be
compared against these baselines with the same protocol.

## 9. AI use
See `AI_USE.md`.
