"""Scripted, reproducible pipeline:  ingest -> split -> train -> evaluate -> predict.

    python -m rag_eval.pipeline all --raw data/sample_corpus.jsonl --qrels data/sample_qrels.jsonl
    python -m rag_eval.pipeline predict --artifacts artifacts --query "fraudulent title deed"

Stages (each usable alone; all outputs are deterministic given --seed):
  ingest    validate + clean raw JSONL, drop stubs/duplicates, write a report with input hash
  split     seeded dev/test split of the labelled queries (dev tunes, test is untouched)
  train     build the index and grid-search fusion/chunking hyper-parameters on DEV only,
            then serialize the model artifacts (JSON/JSONL/npz, no pickle)
  evaluate  score tuned model + ablation baselines on TEST with bootstrap CIs / paired tests
  predict   query the serialized model
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import random
import subprocess
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from .corpus import build_chunks, clean_text, load_corpus, load_qrels
from .metrics import per_query_metrics
from .run_eval import md_table, summarise
from .searcher import Params, Searcher

K = 10


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git_sha() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], text=True,
                                       stderr=subprocess.DEVNULL).strip()
    except Exception:
        return "unknown"


# ---------------------------------------------------------------- ingest
def ingest(raw: str, out: str, min_chars: int = 300) -> dict:
    out_dir = Path(out); out_dir.mkdir(parents=True, exist_ok=True)
    seen, kept, dropped = set(), [], {"duplicate_id": 0, "too_short": 0, "bad_record": 0}
    for line in Path(raw).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            r = json.loads(line); r["doc_id"], r["text"]
        except Exception:
            dropped["bad_record"] += 1; continue
        if r["doc_id"] in seen:
            dropped["duplicate_id"] += 1; continue
        text = clean_text(r["text"])
        if len(text) < min_chars:
            dropped["too_short"] += 1; continue
        seen.add(r["doc_id"])
        kept.append({"doc_id": r["doc_id"], "title": r.get("title", ""), "court": r.get("court", ""),
                     "year": int(r.get("year", 0) or 0), "cites": r.get("cites", []), "text": text})
    ids = {d["doc_id"] for d in kept}
    dangling = 0
    for d in kept:  # citation edges must point at documents we actually have
        before = len(d["cites"]); d["cites"] = [c for c in d["cites"] if c in ids and c != d["doc_id"]]
        dangling += before - len(d["cites"])
    with open(out_dir / "corpus_clean.jsonl", "w", encoding="utf-8") as fh:
        for d in sorted(kept, key=lambda d: d["doc_id"]):
            fh.write(json.dumps(d, ensure_ascii=False) + "\n")
    rep = {"input": raw, "input_sha256": _sha256(Path(raw)), "docs_kept": len(kept), "dropped": dropped,
           "dangling_citations_removed": dangling, "min_chars": min_chars,
           "docs_with_cites": sum(1 for d in kept if d["cites"]),
           "median_chars": sorted(len(d["text"]) for d in kept)[len(kept) // 2] if kept else 0}
    (out_dir / "ingest_report.json").write_text(json.dumps(rep, indent=2))
    print(f"[ingest] {rep}")
    return rep


# ---------------------------------------------------------------- split
def split(qrels: str, out: str, dev_frac: float = 0.5, seed: int = 0) -> tuple[Path, Path]:
    lines = [l for l in Path(qrels).read_text(encoding="utf-8").splitlines() if l.strip()]
    random.Random(seed).shuffle(lines)
    n_dev = max(1, round(len(lines) * dev_frac)) if len(lines) > 1 else len(lines)
    out_dir = Path(out); out_dir.mkdir(parents=True, exist_ok=True)
    dev, test = out_dir / "dev_qrels.jsonl", out_dir / "test_qrels.jsonl"
    dev.write_text("\n".join(lines[:n_dev]) + "\n"); test.write_text("\n".join(lines[n_dev:]) + "\n")
    print(f"[split] {n_dev} dev / {len(lines) - n_dev} test queries (seed={seed})")
    return dev, test


# ---------------------------------------------------------------- train
GRID = {"chunk_size": [400, 800, 1200], "rrf_k": [20, 60], "w_dense": [0.5, 1.0, 2.0],
        "graph": [False, True], "graph_decay": [0.25, 0.5]}


def _mean_ndcg(s: Searcher, queries) -> float:
    return sum(per_query_metrics(s.rank(q.text, K), q.relevant, K)[f"ndcg@{K}"] for q in queries) / len(queries)


def train(corpus: str, dev_qrels: str, out: str, dense: str = "hashing", seed: int = 0) -> dict:
    docs, dev = load_corpus(corpus), load_qrels(dev_qrels)
    if not dev:
        raise SystemExit("no dev queries: cannot tune")
    cites = {d.doc_id: d.cites for d in docs}
    meta = {d.doc_id: {"title": d.title, "court": d.court, "year": d.year} for d in docs}
    results, t0 = [], time.time()
    best = (-1.0, None, None)
    for cs in GRID["chunk_size"]:
        chunks, owners = build_chunks(docs, target=cs, overlap=cs // 8, clean=False)
        base = Searcher(chunks, owners, cites, Params(chunk_size=cs), dense, meta=meta)
        for rk, wd, g, gd in itertools.product(GRID["rrf_k"], GRID["w_dense"], GRID["graph"], GRID["graph_decay"]):
            if not g and gd != GRID["graph_decay"][0]:
                continue  # decay is meaningless without graph expansion
            p = Params(chunk_size=cs, rrf_k=rk, w_dense=wd, graph=g, graph_decay=gd)
            score = _mean_ndcg(base.with_params(p), dev)
            results.append({**asdict(p), "dev_ndcg@10": round(score, 4)})
            # strict > keeps the FIRST (simplest/smallest-grid-order) config on ties
            if score > best[0] + 1e-12:
                best = (score, p, base)
    score, params, searcher = best
    default_dev = next(r for r in results if r["chunk_size"] == 1200 and r["rrf_k"] == 60
                       and r["w_dense"] == 1.0 and not r["graph"])["dev_ndcg@10"]
    extra = {"seed": seed, "trained_at": datetime.now(timezone.utc).isoformat(), "git_sha": _git_sha(),
             "corpus_sha256": _sha256(Path(corpus)), "dev_qrels": dev_qrels, "n_dev_queries": len(dev),
             "dev_ndcg@10_tuned": round(score, 4), "dev_ndcg@10_default": default_dev,
             "n_configs_tried": len(results), "train_seconds": round(time.time() - t0, 1),
             "grid_top5": sorted(results, key=lambda r: -r["dev_ndcg@10"])[:5]}
    searcher.save(out, extra)
    print(f"[train] tuned dev nDCG@10={score:.3f} (default {default_dev:.3f}) params={asdict(params)} -> {out}")
    return extra


# ---------------------------------------------------------------- evaluate
def evaluate(artifacts: str, test_qrels: str, out: str) -> dict:
    s = Searcher.load(artifacts)
    queries = load_qrels(test_qrels)
    tuned = s.p
    systems = {
        "bm25": Params(**{**asdict(tuned), "w_dense": 0.0, "graph": False}),
        "dense": Params(**{**asdict(tuned), "w_bm25": 0.0, "graph": False}),
        "hybrid_rrf_default": Params(chunk_size=tuned.chunk_size),
        "hybrid_tuned": tuned,
    }
    results = {}
    for name, p in systems.items():
        sx = s.with_params(p); t0 = time.perf_counter()
        pq = {q.query_id: per_query_metrics(sx.rank(q.text, K), q.relevant, K) for q in queries}
        results[name] = {"per_query": pq, "ms_per_query": (time.perf_counter() - t0) / max(len(queries), 1) * 1000}
    rows, keys = summarise(results, K)
    out_dir = Path(out); out_dir.mkdir(parents=True, exist_ok=True)
    cfg = json.loads((Path(artifacts) / "config.json").read_text())
    md = [f"# Held-out TEST results (k={K})\n",
          f"Model artifacts: `{artifacts}` (git {cfg.get('git_sha')}, corpus sha256 {cfg.get('corpus_sha256', '')[:12]}…). "
          f"Hyper-parameters were tuned on {cfg.get('n_dev_queries')} DEV queries only.\n",
          md_table("Test set", rows, keys, K, len(queries), cfg["n_chunks"]),
          "Baselines share the tuned chunk size, so differences isolate retrieval/fusion, not chunking.\n"]
    (out_dir / "test_results.json").write_text(json.dumps(rows, indent=2))
    (out_dir / "test_results.md").write_text("\n".join(md))
    (out_dir / "test_per_query.json").write_text(json.dumps({k: v["per_query"] for k, v in results.items()}, indent=2))
    print("\n".join(md))
    return rows


# ---------------------------------------------------------------- predict
def predict(artifacts: str, query: str, k: int = 5) -> list[dict]:
    s = Searcher.load(artifacts)
    hits = [{"doc_id": d, "score": round(sc, 5), **s.meta.get(d, {}), "snippet": s.best_passage(query, d)}
            for d, sc in s.search(query, k)]
    print(json.dumps(hits, indent=2, ensure_ascii=False))
    return hits


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("ingest"); a.add_argument("--raw", required=True); a.add_argument("--out", default="data/processed"); a.add_argument("--min-chars", type=int, default=300)
    a = sub.add_parser("split"); a.add_argument("--qrels", required=True); a.add_argument("--out", default="data/processed"); a.add_argument("--dev-frac", type=float, default=0.5); a.add_argument("--seed", type=int, default=0)
    a = sub.add_parser("train"); a.add_argument("--corpus", default="data/processed/corpus_clean.jsonl"); a.add_argument("--dev-qrels", default="data/processed/dev_qrels.jsonl"); a.add_argument("--out", default="artifacts"); a.add_argument("--dense", default="hashing"); a.add_argument("--seed", type=int, default=0)
    a = sub.add_parser("evaluate"); a.add_argument("--artifacts", default="artifacts"); a.add_argument("--test-qrels", default="data/processed/test_qrels.jsonl"); a.add_argument("--out", default="results")
    a = sub.add_parser("predict"); a.add_argument("--artifacts", default="artifacts"); a.add_argument("--query", required=True); a.add_argument("--k", type=int, default=5)
    a = sub.add_parser("all"); a.add_argument("--raw", required=True); a.add_argument("--qrels", required=True); a.add_argument("--dense", default="hashing"); a.add_argument("--seed", type=int, default=0); a.add_argument("--min-chars", type=int, default=300)
    n = ap.parse_args(argv)
    if n.cmd == "ingest": ingest(n.raw, n.out, n.min_chars)
    elif n.cmd == "split": split(n.qrels, n.out, n.dev_frac, n.seed)
    elif n.cmd == "train": train(n.corpus, n.dev_qrels, n.out, n.dense, n.seed)
    elif n.cmd == "evaluate": evaluate(n.artifacts, n.test_qrels, n.out)
    elif n.cmd == "predict": predict(n.artifacts, n.query, n.k)
    else:
        ingest(n.raw, "data/processed", n.min_chars)
        split(n.qrels, "data/processed", 0.5, n.seed)
        train("data/processed/corpus_clean.jsonl", "data/processed/dev_qrels.jsonl", "artifacts", n.dense, n.seed)
        evaluate("artifacts", "data/processed/test_qrels.jsonl", "results")


if __name__ == "__main__":
    main()
