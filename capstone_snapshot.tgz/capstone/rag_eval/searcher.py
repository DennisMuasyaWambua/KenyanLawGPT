"""The deployable retrieval model: BM25 + dense fused with weighted RRF and optional
citation-graph expansion. One class is used by training (hyper-parameter search),
evaluation, the CLI and the API, so what is evaluated is exactly what is served."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

import numpy as np

from .retrievers import (BM25, HashingDense, SentenceTransformerDense, graph_expand, rrf,
                         to_doc_ranking, tokenize)


@dataclass
class Params:
    chunk_size: int = 1200
    rrf_k: int = 60
    w_bm25: float = 1.0
    w_dense: float = 1.0
    graph: bool = False
    graph_top_n: int = 5
    graph_decay: float = 0.5
    pool: int = 50


class Searcher:
    def __init__(self, chunks: Sequence[str], owners: Sequence[str], cites: dict[str, list[str]],
                 params: Params, dense_spec: str = "hashing", dense_matrix=None,
                 meta: dict[str, dict] | None = None) -> None:
        self.chunks, self.owners, self.cites = list(chunks), list(owners), cites
        self.p, self.dense_spec, self.meta = params, dense_spec, meta or {}
        self.bm25 = BM25(self.chunks)
        if dense_spec.startswith("st:"):
            self.dense = SentenceTransformerDense(self.chunks, dense_spec[3:], matrix=dense_matrix)
        else:
            self.dense = HashingDense(self.chunks)

    def with_params(self, params: Params) -> "Searcher":
        """Cheap re-parameterisation (shares the built indexes) for hyper-parameter search."""
        clone = object.__new__(Searcher)
        clone.__dict__.update(self.__dict__)
        clone.p = params
        return clone

    def search(self, query: str, k: int = 10) -> list[tuple[str, float]]:
        p = self.p
        rankings, weights = [], []
        if p.w_bm25 > 0:
            rankings.append(to_doc_ranking(self.bm25.scores(query), self.owners, p.pool)); weights.append(p.w_bm25)
        if p.w_dense > 0:
            rankings.append(to_doc_ranking(self.dense.scores(query), self.owners, p.pool)); weights.append(p.w_dense)
        fused = rrf(rankings, p.rrf_k, weights)
        if p.graph:
            fused = graph_expand(fused, self.cites, p.graph_top_n, p.graph_decay)
        return sorted(fused.items(), key=lambda kv: kv[1], reverse=True)[:k]

    def rank(self, query: str, k: int = 10) -> list[str]:
        return [d for d, _ in self.search(query, k)]

    def best_passage(self, query: str, doc_id: str, max_chars: int = 400) -> str:
        """Highest-BM25 chunk of a document, trimmed: the extractive snippet shown to users."""
        sc = self.bm25.scores(query)
        best, best_s = "", -1.0
        for i, o in enumerate(self.owners):
            if o == doc_id and sc[i] > best_s:
                best, best_s = self.chunks[i], sc[i]
        return " ".join(best.split())[:max_chars]

    # -- serialization: JSON/JSONL + npz only (no pickle) ------------------------------
    def save(self, out: str | Path, extra: dict | None = None) -> None:
        out = Path(out); out.mkdir(parents=True, exist_ok=True)
        with open(out / "chunks.jsonl", "w", encoding="utf-8") as fh:
            for t, o in zip(self.chunks, self.owners):
                fh.write(json.dumps({"doc_id": o, "text": t}, ensure_ascii=False) + "\n")
        (out / "cites.json").write_text(json.dumps(self.cites))
        (out / "docs_meta.json").write_text(json.dumps(self.meta, ensure_ascii=False))
        if self.dense_spec.startswith("st:"):
            np.savez_compressed(out / "dense.npz", mat=self.dense.mat)
        cfg = {"params": asdict(self.p), "dense_spec": self.dense_spec, "n_chunks": len(self.chunks),
               "n_docs": len(set(self.owners)), **(extra or {})}
        (out / "config.json").write_text(json.dumps(cfg, indent=2))

    @classmethod
    def load(cls, path: str | Path) -> "Searcher":
        path = Path(path)
        cfg = json.loads((path / "config.json").read_text())
        chunks, owners = [], []
        for line in (path / "chunks.jsonl").read_text(encoding="utf-8").splitlines():
            r = json.loads(line); chunks.append(r["text"]); owners.append(r["doc_id"])
        matrix = np.load(path / "dense.npz")["mat"] if (path / "dense.npz").exists() else None
        return cls(chunks, owners, json.loads((path / "cites.json").read_text()), Params(**cfg["params"]),
                   cfg["dense_spec"], matrix, json.loads((path / "docs_meta.json").read_text()))
