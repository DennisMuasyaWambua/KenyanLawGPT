"""FastAPI model service: POST /query -> ranked precedents with extractive snippets.

The service loads the serialized artifacts produced by `rag_eval.pipeline train`
(ARTIFACTS_DIR, default ./artifacts) and serves exactly the retrieval model that was
evaluated. The summary is EXTRACTIVE (templated from retrieved text, with citations):
it cannot hallucinate a case. LLM synthesis is deliberately out of scope here; see the
report's technique-justification section."""
from __future__ import annotations

import json
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from rag_eval.searcher import Searcher

ARTIFACTS_DIR = Path(os.environ.get("ARTIFACTS_DIR", "artifacts"))
_state: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    if (ARTIFACTS_DIR / "config.json").exists():
        _state["searcher"] = Searcher.load(ARTIFACTS_DIR)
        _state["config"] = json.loads((ARTIFACTS_DIR / "config.json").read_text())
    yield
    _state.clear()


app = FastAPI(title="Kenyan precedent retrieval", version="1.0.0", lifespan=lifespan)


class QueryIn(BaseModel):
    query: str = Field(..., min_length=3, max_length=1000, examples=["Land dispute with fraudulent title deed in Kiambu"])
    k: int = Field(5, ge=1, le=20)


class Hit(BaseModel):
    rank: int
    doc_id: str
    title: str = ""
    court: str = ""
    year: int = 0
    score: float
    snippet: str


class QueryOut(BaseModel):
    query: str
    results: list[Hit]
    summary: str
    latency_ms: float


def _searcher() -> Searcher:
    if "searcher" not in _state:
        raise HTTPException(503, f"model artifacts not found in {ARTIFACTS_DIR}; run the training pipeline first")
    return _state["searcher"]


@app.get("/healthz")
def healthz() -> dict:
    ok = "searcher" in _state
    cfg = _state.get("config", {})
    return {"status": "ok" if ok else "no_model", "n_docs": cfg.get("n_docs"), "n_chunks": cfg.get("n_chunks"),
            "params": cfg.get("params"), "git_sha": cfg.get("git_sha"), "trained_at": cfg.get("trained_at")}


@app.post("/query", response_model=QueryOut)
def query(body: QueryIn) -> QueryOut:
    s = _searcher()
    t0 = time.perf_counter()
    hits = []
    for rank, (doc_id, score) in enumerate(s.search(body.query, body.k), 1):
        m = s.meta.get(doc_id, {})
        hits.append(Hit(rank=rank, doc_id=doc_id, title=m.get("title", ""), court=m.get("court", ""),
                        year=int(m.get("year", 0) or 0), score=round(score, 5),
                        snippet=s.best_passage(body.query, doc_id)))
    if hits:
        cited = "; ".join(f"[{h.rank}] {h.title or h.doc_id}" + (f" ({h.court}, {h.year})" if h.court else "") for h in hits[:3])
        summary = f"Most relevant precedents for this query: {cited}. (Extractive summary: verify against the full judgments.)"
    else:
        summary = "No relevant precedents found."
    return QueryOut(query=body.query, results=hits, summary=summary,
                    latency_ms=round((time.perf_counter() - t0) * 1000, 2))
