# Held-out TEST results (k=10)

Model artifacts: `artifacts` (git bd7b03f, corpus sha256 f702dfb4e9a2…). Hyper-parameters were tuned on 5 DEV queries only.

### Test set
_5 queries, 36 chunks; mean [95% bootstrap CI]_

| system | recall@10 | recall@5 | precision@10 | hit@10 | mrr@10 | ndcg@10 | Δ nDCG@10 vs bm25 (p) | ms/q |
|---|---|---|---|---|---|---|---|---|
| bm25 | 1.000 [1.00, 1.00] | 0.900 [0.70, 1.00] | 0.180 [0.14, 0.20] | 1.000 [1.00, 1.00] | 1.000 [1.00, 1.00] | 0.928 [0.86, 0.99] | — | 0.07 |
| dense | 1.000 [1.00, 1.00] | 0.800 [0.60, 1.00] | 0.180 [0.14, 0.20] | 1.000 [1.00, 1.00] | 0.740 [0.42, 1.00] | 0.776 [0.57, 0.97] | -0.152 (p=0.16) | 0.17 |
| hybrid_rrf_default | 1.000 [1.00, 1.00] | 0.900 [0.70, 1.00] | 0.180 [0.14, 0.20] | 1.000 [1.00, 1.00] | 0.900 [0.70, 1.00] | 0.889 [0.75, 0.99] | -0.038 (p=0.65) | 0.22 |
| hybrid_tuned | 1.000 [1.00, 1.00] | 0.900 [0.70, 1.00] | 0.180 [0.14, 0.20] | 1.000 [1.00, 1.00] | 0.900 [0.70, 1.00] | 0.889 [0.75, 0.99] | -0.038 (p=0.65) | 0.19 |

Baselines share the tuned chunk size, so differences isolate retrieval/fusion, not chunking.
