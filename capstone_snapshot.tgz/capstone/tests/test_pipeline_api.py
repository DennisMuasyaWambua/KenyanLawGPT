import json, sys, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from rag_eval import pipeline
from rag_eval.searcher import Params, Searcher

DATA = ROOT / "data"


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(); t = Path(cls.tmp.name)
        pipeline.ingest(str(DATA / "sample_corpus.jsonl"), str(t / "p"))
        dev, test = pipeline.split(str(DATA / "sample_qrels.jsonl"), str(t / "p"))
        pipeline.train(str(t / "p/corpus_clean.jsonl"), str(dev), str(t / "art"))
        cls.t, cls.test = t, test

    @classmethod
    def tearDownClass(cls): cls.tmp.cleanup()

    def test_split_is_disjoint_and_deterministic(self):
        d = {json.loads(l)["query_id"] for l in (self.t / "p/dev_qrels.jsonl").read_text().split("\n") if l}
        te = {json.loads(l)["query_id"] for l in self.test.read_text().split("\n") if l}
        self.assertFalse(d & te); self.assertEqual(len(d | te), 10)

    def test_artifacts_roundtrip_gives_identical_rankings(self):
        a = Searcher.load(self.t / "art"); b = Searcher.load(self.t / "art")
        for q in ["forged land title", "dismissed without hearing"]:
            self.assertEqual(a.rank(q), b.rank(q))
        self.assertTrue((self.t / "art/config.json").exists())

    def test_ingest_report_and_no_dangling_cites(self):
        rep = json.loads((self.t / "p/ingest_report.json").read_text())
        self.assertEqual(rep["docs_kept"], 12); self.assertEqual(rep["dangling_citations_removed"], 0)

    def test_evaluate_writes_results(self):
        rows = pipeline.evaluate(str(self.t / "art"), str(self.test), str(self.t / "res"))
        self.assertIn("hybrid_tuned", rows); self.assertTrue((self.t / "res/test_results.md").exists())

    def test_graph_expansion_surfaces_cited_doc(self):
        s = Searcher.load(self.t / "art").with_params(Params(w_dense=0.0, graph=True, graph_decay=0.9))
        self.assertIn("SYN-002", s.rank("title deed Kiambu fraud", 5))


class ApiTests(unittest.TestCase):
    def test_api(self):
        try:
            from fastapi.testclient import TestClient
        except ImportError:
            self.skipTest("fastapi/httpx not installed")
        import os
        with tempfile.TemporaryDirectory() as tmp:
            t = Path(tmp)
            pipeline.ingest(str(DATA / "sample_corpus.jsonl"), str(t / "p"))
            dev, _ = pipeline.split(str(DATA / "sample_qrels.jsonl"), str(t / "p"))
            pipeline.train(str(t / "p/corpus_clean.jsonl"), str(dev), str(t / "art"))
            os.environ["ARTIFACTS_DIR"] = str(t / "art")
            import importlib
            from rag_service import app as appmod
            importlib.reload(appmod)
            with TestClient(appmod.app) as c:
                self.assertEqual(c.get("/healthz").json()["status"], "ok")
                r = c.post("/query", json={"query": "fraudulent title deed in Kiambu", "k": 3})
                self.assertEqual(r.status_code, 200); body = r.json()
                self.assertEqual(body["results"][0]["doc_id"], "SYN-001")
                self.assertIn("[1]", body["summary"])
                self.assertEqual(c.post("/query", json={"query": "x"}).status_code, 422)
                self.assertEqual(c.post("/query", json={"query": "land", "k": 99}).status_code, 422)
            os.environ["ARTIFACTS_DIR"] = str(t / "missing")
            importlib.reload(appmod)
            with TestClient(appmod.app) as c:
                self.assertEqual(c.post("/query", json={"query": "land title"}).status_code, 503)


if __name__ == "__main__":
    unittest.main()
